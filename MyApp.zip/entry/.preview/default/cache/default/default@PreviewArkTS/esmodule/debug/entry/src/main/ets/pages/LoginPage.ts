if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface LoginPage_Params {
    account?: string;
    password?: string;
    isShowProgress?: boolean;
    timeOutId?: number;
    pathStack?: NavPathStack;
}
import promptAction from "@ohos:promptAction";
function __TextInput__inputStype(): void {
    TextInput.placeholderColor('#99182431');
    TextInput.height('45vp');
    TextInput.fontSize('18fp');
    TextInput.backgroundColor('#F1F3F5');
    TextInput.width('100%');
    TextInput.margin({ top: 12 });
}
function __Line__lineStyle(): void {
    Line.width('100%');
    Line.height('1vp');
    Line.backgroundColor('#33182431');
}
function __Text__blueTextStyle(): void {
    Text.fontColor('#007DFF');
    Text.fontSize('14fp');
    Text.fontWeight(FontWeight.Medium);
}
class LoginPage extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__account = new ObservedPropertySimplePU('', this, "account");
        this.__password = new ObservedPropertySimplePU('', this, "password");
        this.__isShowProgress = new ObservedPropertySimplePU(false, this, "isShowProgress");
        this.timeOutId = -1;
        this.pathStack = new NavPathStack();
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: LoginPage_Params) {
        if (params.account !== undefined) {
            this.account = params.account;
        }
        if (params.password !== undefined) {
            this.password = params.password;
        }
        if (params.isShowProgress !== undefined) {
            this.isShowProgress = params.isShowProgress;
        }
        if (params.timeOutId !== undefined) {
            this.timeOutId = params.timeOutId;
        }
        if (params.pathStack !== undefined) {
            this.pathStack = params.pathStack;
        }
    }
    updateStateVars(params: LoginPage_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__account.purgeDependencyOnElmtId(rmElmtId);
        this.__password.purgeDependencyOnElmtId(rmElmtId);
        this.__isShowProgress.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__account.aboutToBeDeleted();
        this.__password.aboutToBeDeleted();
        this.__isShowProgress.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __account: ObservedPropertySimplePU<string>;
    get account() {
        return this.__account.get();
    }
    set account(newValue: string) {
        this.__account.set(newValue);
    }
    private __password: ObservedPropertySimplePU<string>;
    get password() {
        return this.__password.get();
    }
    set password(newValue: string) {
        this.__password.set(newValue);
    }
    private __isShowProgress: ObservedPropertySimplePU<boolean>;
    get isShowProgress() {
        return this.__isShowProgress.get();
    }
    set isShowProgress(newValue: boolean) {
        this.__isShowProgress.set(newValue);
    }
    private timeOutId: number;
    private pathStack: NavPathStack;
    imageButton(src: Resource, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithChild({ type: ButtonType.Circle, stateEffect: true });
            Button.debugLine("entry/src/main/ets/pages/LoginPage.ets(40:5)", "entry");
            Button.height('48vp');
            Button.width('48vp');
            Button.backgroundColor('#F1F3F5');
        }, Button);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(src);
            Image.debugLine("entry/src/main/ets/pages/LoginPage.ets(41:7)", "entry");
        }, Image);
        Button.pop();
    }
    login(result: boolean): void {
        if (!this.account || !this.password) {
            promptAction.showToast({
                message: '账号密码不能为空！'
            });
        }
        else {
            this.isShowProgress = true;
            if (this.timeOutId === -1) {
                this.timeOutId = setTimeout(() => {
                    this.isShowProgress = false;
                    this.timeOutId = -1;
                    this.pathStack.pushPathByName('MainPage', null);
                }, 2000);
            }
        }
    }
    aboutToDisappear() {
        clearTimeout(this.timeOutId);
        this.timeOutId = -1;
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Navigation.create(this.pathStack, { moduleName: "entry", pagePath: "entry/src/main/ets/pages/LoginPage", isUserCreateStack: true });
            Navigation.debugLine("entry/src/main/ets/pages/LoginPage.ets(71:5)", "entry");
            Navigation.backgroundColor('#F1F3F5');
            Navigation.width('100%');
            Navigation.height('100%');
            Navigation.hideTitleBar(true);
            Navigation.hideToolBar(true);
        }, Navigation);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/LoginPage.ets(72:7)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#f1f3f5');
            Column.padding({
                left: '12vp',
                right: '12vp',
                bottom: '24vp'
            });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777230, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/LoginPage.ets(73:9)", "entry");
            Image.width('78vp');
            Image.height('78vp');
            Image.margin({ top: '150vp', bottom: '8vp' });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('登录界面');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(77:9)", "entry");
            Text.fontWeight(FontWeight.Medium);
            Text.fontSize('24fp');
            Text.fontColor('#182431');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('登录账号获取更多服务');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(81:9)", "entry");
            Text.fontSize('16fp');
            Text.fontColor('#99182431');
            Text.margin({ bottom: '30vp', top: '8vp' });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入账号' });
            TextInput.debugLine("entry/src/main/ets/pages/LoginPage.ets(85:9)", "entry");
            TextInput.type(InputType.Number);
            TextInput.maxLength(11);
            __TextInput__inputStype();
            TextInput.onChange((value: string) => {
                this.account = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Line.create();
            Line.debugLine("entry/src/main/ets/pages/LoginPage.ets(92:9)", "entry");
            __Line__lineStyle();
        }, Line);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '请输入密码' });
            TextInput.debugLine("entry/src/main/ets/pages/LoginPage.ets(94:9)", "entry");
            TextInput.type(InputType.Password);
            TextInput.maxLength(8);
            __TextInput__inputStype();
            TextInput.onChange((value: string) => {
                this.password = value;
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Line.create();
            Line.debugLine("entry/src/main/ets/pages/LoginPage.ets(101:9)", "entry");
            __Line__lineStyle();
        }, Line);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/LoginPage.ets(103:9)", "entry");
            Row.width('100%');
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.margin({ top: '8vp' });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('短信验证码登录');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(104:11)", "entry");
            __Text__blueTextStyle();
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('忘记密码');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(106:11)", "entry");
            __Text__blueTextStyle();
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('登录');
            Button.debugLine("entry/src/main/ets/pages/LoginPage.ets(113:9)", "entry");
            Button.width('90%');
            Button.height('40vp');
            Button.fontSize('16fp');
            Button.fontWeight(FontWeight.Medium);
            Button.backgroundColor('#007DFF');
            Button.margin({ top: '48vp', bottom: '12vp' });
            Button.onClick(() => {
                this.login(true);
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('注册账号');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(123:9)", "entry");
            Text.fontColor('#007DFF');
            Text.fontSize('16fp');
            Text.fontWeight(FontWeight.Medium);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (this.isShowProgress) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        LoadingProgress.create();
                        LoadingProgress.debugLine("entry/src/main/ets/pages/LoginPage.ets(128:11)", "entry");
                        LoadingProgress.color('#182431');
                        LoadingProgress.width('30vp');
                        LoadingProgress.height('30vp');
                        LoadingProgress.margin({ top: '20vp' });
                    }, LoadingProgress);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                });
            }
        }, If);
        If.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('其他登录方式');
            Text.debugLine("entry/src/main/ets/pages/LoginPage.ets(134:9)", "entry");
            Text.fontColor('#838D97');
            Text.fontSize('12fp');
            Text.fontWeight(FontWeight.Medium);
            Text.margin({ top: '50vp', bottom: '12vp' });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create({ space: 44 });
            Row.debugLine("entry/src/main/ets/pages/LoginPage.ets(139:9)", "entry");
            Row.margin({ bottom: '16vp' });
        }, Row);
        this.imageButton.bind(this)({ "id": 16777220, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
        this.imageButton.bind(this)({ "id": 16777218, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
        this.imageButton.bind(this)({ "id": 16777219, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
        Row.pop();
        Column.pop();
        Navigation.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "LoginPage";
    }
}
registerNamedRoute(() => new LoginPage(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/LoginPage", pageFullPath: "entry/src/main/ets/pages/LoginPage", integratedHsp: "false", moduleType: "followWithHap" });
