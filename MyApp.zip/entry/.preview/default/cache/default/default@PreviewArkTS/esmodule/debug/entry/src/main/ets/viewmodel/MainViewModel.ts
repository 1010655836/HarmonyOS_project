import ItemData from "@normalized:N&&&entry/src/main/ets/viewmodel/ItemData&";
export class MainViewModel {
    getSwiperImages(): Array<Resource> {
        const swiperImages: Resource[] = [
            { "id": 16777254, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" },
            { "id": 16777243, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" },
            { "id": 16777245, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" },
            { "id": 16777234, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }
        ];
        return swiperImages;
    }
    getFirstGridData(): Array<ItemData> {
        const firstGridData: ItemData[] = [
            new ItemData(0, '我的最爱', { "id": 16777251, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }),
            new ItemData(1, '历史记录', { "id": 16777240, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }),
            new ItemData(2, '消息', { "id": 16777255, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }),
            new ItemData(3, '购物车', { "id": 16777256, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }),
            new ItemData(4, '我的目标', { "id": 16777233, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }),
            new ItemData(5, '圈子', { "id": 16777236, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }),
            new ItemData(6, '收藏', { "id": 16777257, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }),
            new ItemData(7, '回收站', { "id": 16777246, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" })
        ];
        return firstGridData;
    }
    getSttingListData(): Array<Array<ItemData>> {
        let settingListData: ItemData[][] = [
            [
                new ItemData(0, '推送通知', { "id": 16777250, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }, '切换按钮'),
            ],
            [
                new ItemData(1, '字体大小调节', { "id": 16777238, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }),
                new ItemData(2, '菜单设置', { "id": 16777259, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }),
            ],
            [
                new ItemData(3, '清除缓存', { "id": 16777253, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }),
                new ItemData(4, '隐私协议', { "id": 16777237, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" }),
            ],
            [
                new ItemData(5, '关于', { "id": 16777248, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" })
            ]
        ];
        return settingListData;
    }
}
export default new MainViewModel();
