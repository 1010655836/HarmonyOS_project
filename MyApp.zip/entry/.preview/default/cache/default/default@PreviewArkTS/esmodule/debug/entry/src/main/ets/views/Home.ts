if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Home_Params {
    httpGridItems?: Array<ListInfo>;
    pictureUri?: string;
    swiperController?: SwiperController;
    context?;
    applicationContext?;
    cacheDir?;
}
import MainViewModel from "@normalized:N&&&entry/src/main/ets/viewmodel/MainViewModel&";
import type ItemData from '../viewmodel/ItemData';
import type ListInfo from '../viewmodel/ResponseData/ListInfo';
import type common from "@ohos:app.ability.common";
import { HttpUtils } from "@normalized:N&&&entry/src/main/ets/common/network/HttpUtils&";
export default class Home extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__httpGridItems = new ObservedPropertyObjectPU([], this, "httpGridItems");
        this.__pictureUri = new ObservedPropertySimplePU('', this, "pictureUri");
        this.swiperController = new SwiperController();
        this.context = getContext(this) as common.UIAbilityContext;
        this.applicationContext = this.context.getApplicationContext();
        this.cacheDir = this.applicationContext.filesDir;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Home_Params) {
        if (params.httpGridItems !== undefined) {
            this.httpGridItems = params.httpGridItems;
        }
        if (params.pictureUri !== undefined) {
            this.pictureUri = params.pictureUri;
        }
        if (params.swiperController !== undefined) {
            this.swiperController = params.swiperController;
        }
        if (params.context !== undefined) {
            this.context = params.context;
        }
        if (params.applicationContext !== undefined) {
            this.applicationContext = params.applicationContext;
        }
        if (params.cacheDir !== undefined) {
            this.cacheDir = params.cacheDir;
        }
    }
    updateStateVars(params: Home_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__httpGridItems.purgeDependencyOnElmtId(rmElmtId);
        this.__pictureUri.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__httpGridItems.aboutToBeDeleted();
        this.__pictureUri.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __httpGridItems: ObservedPropertyObjectPU<Array<ListInfo>>;
    get httpGridItems() {
        return this.__httpGridItems.get();
    }
    set httpGridItems(newValue: Array<ListInfo>) {
        this.__httpGridItems.set(newValue);
    }
    private __pictureUri: ObservedPropertySimplePU<string>;
    get pictureUri() {
        return this.__pictureUri.get();
    }
    set pictureUri(newValue: string) {
        this.__pictureUri.set(newValue);
    }
    private swiperController: SwiperController;
    private context;
    private applicationContext;
    private cacheDir;
    async aboutToAppear(): Promise<void> {
        let httpUtil: HttpUtils = new HttpUtils();
        const list: Array<ListInfo> = await httpUtil.postHttpRequest();
        this.httpGridItems = list;
        httpUtil.getHttpRequest(this.cacheDir).then((value: string) => {
            this.pictureUri = value;
        });
        httpUtil.destroyHttpRequest();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/views/Home.ets(28:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#F1F3F5');
            Column.justifyContent(FlexAlign.Start);
            Column.alignItems(HorizontalAlign.Start);
            Column.padding('12vp');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('首页');
            Text.debugLine("entry/src/main/ets/views/Home.ets(29:7)", "entry");
            Text.width('100%');
            Text.margin({
                top: '48vp',
                bottom: '12vp'
            });
            Text.fontWeight(700);
            Text.fontSize('26fp');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Swiper.create(this.swiperController);
            Swiper.debugLine("entry/src/main/ets/views/Home.ets(37:7)", "entry");
            Swiper.autoPlay(true);
        }, Swiper);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Image.create(item);
                    Image.debugLine("entry/src/main/ets/views/Home.ets(39:11)", "entry");
                    Image.width('100%');
                    Image.borderRadius('16vp');
                }, Image);
            };
            this.forEachUpdateFunction(elmtId, MainViewModel.getSwiperImages(), forEachItemGenFunction, (img: Resource) => JSON.stringify(img), false, false);
        }, ForEach);
        ForEach.pop();
        Swiper.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Grid.create();
            Grid.debugLine("entry/src/main/ets/views/Home.ets(46:7)", "entry");
            Grid.columnsTemplate('1fr 1fr 1fr 1fr');
            Grid.rowsTemplate('1fr 1fr');
            Grid.columnsGap('8vp');
            Grid.rowsGap('12vp');
            Grid.backgroundImage({ "id": 16777239, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Grid.backgroundImageSize({
                width: '100%',
                height: '156vp'
            });
            Grid.margin({ top: '12vp' });
            Grid.padding({
                top: '12vp',
                bottom: '12vp'
            });
            Grid.height('156vp');
            Grid.backgroundColor(Color.White);
            Grid.borderRadius('16fp');
        }, Grid);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        GridItem.create(() => { }, false);
                        GridItem.debugLine("entry/src/main/ets/views/Home.ets(48:11)", "entry");
                    };
                    const observedDeepRender = () => {
                        this.observeComponentCreation2(itemCreation2, GridItem);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create();
                            Column.debugLine("entry/src/main/ets/views/Home.ets(49:13)", "entry");
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Image.create(item.img);
                            Image.debugLine("entry/src/main/ets/views/Home.ets(50:15)", "entry");
                            Image.width('40vp');
                            Image.height('40vp');
                        }, Image);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.title);
                            Text.debugLine("entry/src/main/ets/views/Home.ets(53:15)", "entry");
                            Text.fontSize('12fp');
                            Text.margin({ top: '4vp' });
                        }, Text);
                        Text.pop();
                        Column.pop();
                        GridItem.pop();
                    };
                    observedDeepRender();
                }
            };
            this.forEachUpdateFunction(elmtId, MainViewModel.getFirstGridData(), forEachItemGenFunction, (item: ItemData) => JSON.stringify(item), false, false);
        }, ForEach);
        ForEach.pop();
        Grid.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('列表');
            Text.debugLine("entry/src/main/ets/views/Home.ets(78:7)", "entry");
            Text.fontSize('18fp');
            Text.fontWeight(700);
            Text.width('100%');
            Text.margin({
                top: '18vp',
                bottom: '8vp'
            });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create();
            List.debugLine("entry/src/main/ets/views/Home.ets(86:7)", "entry");
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        itemCreation2(elmtId, isInitialRender);
                        if (!isInitialRender) {
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        ListItem.margin({ bottom: '8vp' });
                        ListItem.borderRadius('16vp');
                        ListItem.backgroundColor('#ffffff');
                        ListItem.borderRadius('4vp');
                        ListItem.align(Alignment.TopStart);
                        ListItem.width('100%');
                        ListItem.debugLine("entry/src/main/ets/views/Home.ets(88:11)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/views/Home.ets(89:13)", "entry");
                            Row.width('100%');
                            Row.padding({
                                left: '12vp',
                                right: '12vp',
                                top: '12vp',
                                bottom: '12vp'
                            });
                            Row.justifyContent(FlexAlign.SpaceBetween);
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Image.create(item.indexNavPic);
                            Image.debugLine("entry/src/main/ets/views/Home.ets(90:15)", "entry");
                            Image.width('130vp');
                            Image.height('80vp');
                            Image.objectFit(ImageFit.TOP_START);
                            Image.borderRadius('8vp');
                            Image.margin({ right: '12vp' });
                        }, Image);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create();
                            Column.debugLine("entry/src/main/ets/views/Home.ets(96:15)", "entry");
                            Column.alignItems(HorizontalAlign.Start);
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.activityName);
                            Text.debugLine("entry/src/main/ets/views/Home.ets(97:17)", "entry");
                            Text.width('190vp');
                            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                            Text.maxLines(1);
                            Text.fontSize('16fp');
                            Text.fontColor('#99182431');
                            Text.fontWeight(FontWeight.Medium);
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.theme);
                            Text.debugLine("entry/src/main/ets/views/Home.ets(104:17)", "entry");
                            Text.width('190vp');
                            Text.textOverflow({ overflow: TextOverflow.Ellipsis });
                            Text.maxLines(2);
                            Text.margin({ top: '4vp' });
                            Text.fontSize('12fp');
                            Text.fontColor('#99182431');
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/views/Home.ets(111:17)", "entry");
                            Row.width('170vp');
                            Row.margin({ top: '10.5vp' });
                            Row.justifyContent(FlexAlign.End);
                            Row.alignItems(VerticalAlign.Bottom);
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Image.create(this.pictureUri);
                            Image.debugLine("entry/src/main/ets/views/Home.ets(112:19)", "entry");
                            Image.width('20vp');
                            Image.opacity(0.5);
                        }, Image);
                        Row.pop();
                        Column.pop();
                        Row.pop();
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.httpGridItems, forEachItemGenFunction, (item: ListInfo) => JSON.stringify(item), false, false);
        }, ForEach);
        ForEach.pop();
        List.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    storePreviewComponents(1, "Home", new Home(undefined, {}));
    previewComponent();
}
else {
}
