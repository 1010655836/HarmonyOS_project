if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Setting_Params {
}
import type ItemData from '../viewmodel/ItemData';
import mainViewModel from "@normalized:N&&&entry/src/main/ets/viewmodel/MainViewModel&";
export default class Setting extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Setting_Params) {
    }
    updateStateVars(params: Setting_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    settingCell(item: ItemData, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/views/Setting.ets(9:5)", "entry");
            Row.justifyContent(FlexAlign.SpaceBetween);
            Row.width('100%');
            Row.padding({
                left: '8vp',
                right: '22vp'
            });
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/views/Setting.ets(10:7)", "entry");
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create(item.img);
            Image.debugLine("entry/src/main/ets/views/Setting.ets(11:9)", "entry");
            Image.height('22vp');
            Image.margin({
                left: '16vp',
                right: '12vp'
            });
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create(item.title);
            Text.debugLine("entry/src/main/ets/views/Setting.ets(17:9)", "entry");
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            If.create();
            if (!item.others) {
                this.ifElseBranchUpdateFunction(0, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Image.create({ "id": 16777252, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
                        Image.debugLine("entry/src/main/ets/views/Setting.ets(20:9)", "entry");
                        Image.width('12vp');
                        Image.height('24vp');
                    }, Image);
                });
            }
            else {
                this.ifElseBranchUpdateFunction(1, () => {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        Toggle.create({ type: ToggleType.Switch, isOn: false });
                        Toggle.debugLine("entry/src/main/ets/views/Setting.ets(24:9)", "entry");
                    }, Toggle);
                    Toggle.pop();
                });
            }
        }, If);
        If.pop();
        Row.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/views/Setting.ets(35:5)", "entry");
            Column.backgroundColor('#F1F3F5');
            Column.width('100%');
            Column.height('100%');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('我的');
            Text.debugLine("entry/src/main/ets/views/Setting.ets(36:7)", "entry");
            Text.width('100%');
            Text.margin({
                top: '48vp',
                bottom: '12vp'
            });
            Text.fontWeight(700);
            Text.fontSize('26fp');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/views/Setting.ets(44:7)", "entry");
            Row.alignItems(VerticalAlign.Center);
            Row.width('100%');
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 16777242, "type": 20000, params: [], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/views/Setting.ets(45:9)", "entry");
            Image.width('48vp');
            Image.height('48vp');
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/views/Setting.ets(48:9)", "entry");
            Column.alignItems(HorizontalAlign.Start);
            Column.margin({ left: '12vp' });
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('WJh');
            Text.debugLine("entry/src/main/ets/views/Setting.ets(49:11)", "entry");
            Text.fontSize('20fp');
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('vy666@qq.com');
            Text.debugLine("entry/src/main/ets/views/Setting.ets(51:11)", "entry");
            Text.fontSize('12fp');
            Text.margin({ top: '4vp' });
        }, Text);
        Text.pop();
        Column.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create();
            List.debugLine("entry/src/main/ets/views/Setting.ets(60:7)", "entry");
            List.scrollBar(BarState.Off);
            List.width('100%');
            List.padding({
                top: '4vp',
                bottom: '4vp'
            });
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    ListItemGroup.create();
                    ListItemGroup.debugLine("entry/src/main/ets/views/Setting.ets(62:11)", "entry");
                    ListItemGroup.divider({
                        strokeWidth: '1vp',
                        color: '#0d000000',
                        startMargin: '42vp',
                        endMargin: '24vp'
                    });
                    ListItemGroup.backgroundColor('#ffffff');
                    ListItemGroup.borderRadius('16vp');
                    ListItemGroup.margin({
                        top: '4vp',
                        bottom: '4vp'
                    });
                }, ListItemGroup);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    ForEach.create();
                    const forEachItemGenFunction = _item => {
                        const cell = _item;
                        {
                            const itemCreation = (elmtId, isInitialRender) => {
                                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                                itemCreation2(elmtId, isInitialRender);
                                if (!isInitialRender) {
                                    ListItem.pop();
                                }
                                ViewStackProcessor.StopGetAccessRecording();
                            };
                            const itemCreation2 = (elmtId, isInitialRender) => {
                                ListItem.create(deepRenderFunction, true);
                                ListItem.height('48vp');
                                ListItem.debugLine("entry/src/main/ets/views/Setting.ets(64:15)", "entry");
                            };
                            const deepRenderFunction = (elmtId, isInitialRender) => {
                                itemCreation(elmtId, isInitialRender);
                                this.settingCell.bind(this)(cell);
                                ListItem.pop();
                            };
                            this.observeComponentCreation2(itemCreation2, ListItem);
                            ListItem.pop();
                        }
                    };
                    this.forEachUpdateFunction(elmtId, item, forEachItemGenFunction);
                }, ForEach);
                ForEach.pop();
                ListItemGroup.pop();
            };
            this.forEachUpdateFunction(elmtId, mainViewModel.getSttingListData(), forEachItemGenFunction, (item: ItemData) => JSON.stringify(item), false, false);
        }, ForEach);
        ForEach.pop();
        List.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/views/Setting.ets(90:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('退出登录', { type: ButtonType.Capsule });
            Button.debugLine("entry/src/main/ets/views/Setting.ets(91:7)", "entry");
            Button.width('90%');
            Button.height('40vp');
            Button.fontSize('16fp');
            Button.fontColor('#FA2A2D');
            Button.fontWeight(FontWeight.Medium);
            Button.backgroundColor('#E5E8EA');
            Button.margin({ bottom: '16vp' });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
if (getPreviewComponentFlag()) {
    storePreviewComponents(1, "Setting", new Setting(undefined, {}));
    previewComponent();
}
else {
}
